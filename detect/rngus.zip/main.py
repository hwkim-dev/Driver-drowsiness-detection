import multiprocessing
import output_predict
import winsound
import tkinter as tk
import detection
import time
import sched
import sys


class process_Manager:
    def __init__(self):
        self.detect_p = detection.detect_process()
        self.output_predict_main = output_predict.predict()
        self.running = True
        self.predict = None

    def process_run(self):
        # Start the prediction process
        self.predict = multiprocessing.Process(target=self.output_predict_main.run, args=(self.detect_p,))
        self.predict.start()

    def quit(self):
        self.running = False
        winsound.PlaySound(None, winsound.SND_PURGE)
        if self.predict is not None:
            self.predict.terminate()
        root.destroy()


if __name__ == '__main__':
    manager = process_Manager()

    root = tk.Tk()
    root.geometry("150x150")

    small_button = tk.Button(root, command=manager.quit, text="exit", width=5, height=2, font=10)
    small_button.pack()
    small_button = tk.Button(root, command=manager.process_run, text="start", width=5, height=2, font=10)
    small_button.pack()

    root.mainloop()

# import multiprocessing
# import output_predict
# import winsound
# import tkinter as tk
# import detection
# import time
# import sched
# import sys
#
#
# class process_Manager:
#     def __init__(self):
#         self.detect_p = detection.detect_process()
#         self.output_predict_main = output_predict.predict()
#         self.running = True
#         self.predict = None
#         self.check = None
#
#     def process_run(self):
#         # self.check = multiprocessing.Process(target=self.detect_p.check_warn)
#         self.predict = multiprocessing.Process(target=self.output_predict_main.run, args=(self.detect_p,))
#         # self.check.start()
#         self.predict.start()
#
#     def quit(self):
#         self.running = False
#         winsound.PlaySound(None, winsound.SND_PURGE)
#         if self.predict is not None:
#             self.predict.terminate()
#         if self.check is not None:
#             self.check.terminate()
#         root.destroy()
#
#
# if __name__ == '__main__':
#     manager = process_Manager()
#
#     root = tk.Tk()
#     root.geometry("150x150")
#
#     small_button = tk.Button(root, command=manager.quit, text="exit", width=5, height=2, font=10)
#     small_button.pack()
#     small_button = tk.Button(root, command=manager.process_run, text="start", width=5, height=2, font=10)
#     small_button.pack()
#
#     root.mainloop()